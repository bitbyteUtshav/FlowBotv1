import React, { useEffect, useMemo, useState } from 'react';
import { api, loadChannels } from '../api';

export default function BroadcastsView() {
  const [channels,setChannels]=useState([]),[channelId,setChannelId]=useState('');
  const [campaigns,setCampaigns]=useState([]),[tags,setTags]=useState([]);
  const [campaignName,setCampaignName]=useState(''),[messageBody,setMessageBody]=useState(''),[tagId,setTagId]=useState('');
  const [templateName,setTemplateName]=useState(''),[templateLanguage,setTemplateLanguage]=useState('en_US');
  const [loading,setLoading]=useState(false),[sending,setSending]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const selected=useMemo(()=>channels.find(c=>String(c.id)===String(channelId)),[channels,channelId]);
  const isMeta=selected && ['facebook','instagram','whatsapp'].includes(selected.platform);
  useEffect(()=>{loadChannels().then(list=>{setChannels(list);const saved=localStorage.getItem('flowbot_broadcast_channel');const chosen=list.find(c=>String(c.id)===String(saved))||list[0];if(chosen)setChannelId(String(chosen.id));}).catch(e=>setError(e.message));},[]);
  const reload=async id=>{if(!id)return;const ch=channels.find(c=>String(c.id)===String(id));const platform=ch?.platform;setLoading(true);setError('');try{const endpoint=['facebook','instagram','whatsapp'].includes(platform)?`/api/meta/${id}/broadcasts`:`/api/telegram/${id}/broadcasts`;const [b,t]=await Promise.all([api(endpoint),api(`/api/telegram/${id}/tags`)]);setCampaigns(b);setTags(t);}catch(e){setError(e.message);setCampaigns([]);setTags([]);}finally{setLoading(false)}};
  useEffect(()=>{if(channelId){localStorage.setItem('flowbot_broadcast_channel',String(channelId));reload(channelId)}},[channelId,channels.length]);
  const send=async e=>{e.preventDefault();if(!campaignName.trim()||!channelId)return;if(selected?.platform!=='whatsapp'&&!messageBody.trim())return;if(selected?.platform==='whatsapp'&&!templateName.trim())return;setSending(true);setError('');setNotice('');try{const endpoint=isMeta?`/api/meta/${channelId}/broadcasts`:`/api/telegram/${channelId}/broadcasts`;const body={name:campaignName.trim(),message:messageBody.trim(),tag_id:tagId?Number(tagId):null};if(selected?.platform==='whatsapp'){body.template_name=templateName.trim();body.template_language=templateLanguage.trim();}const result=await api(endpoint,{method:'POST',body:JSON.stringify(body)});setCampaignName('');setMessageBody('');setTagId('');setTemplateName('');setNotice(`Campaign queued. Eligible recipients: ${result.recipient_count ?? 'will be calculated by the worker'}.`);await reload(channelId);}catch(e){setError(e.message)}finally{setSending(false)}};
  return <div className="space-y-6">
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between"><div><h3 className="text-base font-semibold text-slate-800">নতুন ব্রডকাস্ট ক্যাম্পেইন</h3><p className="text-xs text-slate-500 mt-1">Connected channel অনুযায়ী policy-aware campaign তৈরি করুন।</p></div>
        <select value={channelId} onChange={e=>setChannelId(e.target.value)} className="text-xs border rounded-lg px-3 py-2 bg-white"><option value="">Select channel</option>{channels.map(c=><option key={c.id} value={c.id}>{c.page_name} ({c.platform})</option>)}</select>
      </div>
      {error&&<p role="alert" className="text-sm text-red-600 bg-red-50 rounded-lg p-3">{error}</p>}{notice&&<p role="status" className="text-sm text-emerald-700 bg-emerald-50 rounded-lg p-3">{notice}</p>}
      {!selected?<p className="text-sm text-slate-500">Connect a messaging channel first.</p>:<form onSubmit={send} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label className="text-xs font-medium text-slate-600 block">ক্যাম্পেইনের নাম<input required value={campaignName} onChange={e=>setCampaignName(e.target.value)} placeholder="e.g. Product update" className="mt-1 w-full text-sm border px-3 py-2.5 rounded-xl"/></label>
          <label className="text-xs font-medium text-slate-600 block">Target audience<select value={tagId} onChange={e=>setTagId(e.target.value)} className="mt-1 w-full text-sm border px-3 py-2.5 rounded-xl bg-white"><option value="">All eligible contacts</option>{tags.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></label>
        </div>
        {selected.platform==='whatsapp'?<div className="grid grid-cols-1 md:grid-cols-2 gap-4"><label className="text-xs font-medium text-slate-600 block">Approved WhatsApp template name<input required value={templateName} onChange={e=>setTemplateName(e.target.value)} placeholder="approved_template_name" className="mt-1 w-full text-sm border px-3 py-2.5 rounded-xl"/></label><label className="text-xs font-medium text-slate-600 block">Template language code<input required value={templateLanguage} onChange={e=>setTemplateLanguage(e.target.value)} placeholder="en_US" className="mt-1 w-full text-sm border px-3 py-2.5 rounded-xl"/></label></div>:<label className="text-xs font-medium text-slate-600 block">মেসেজ বডি<textarea required rows={3} maxLength={2000} value={messageBody} onChange={e=>setMessageBody(e.target.value)} placeholder="আপনার বার্তা লিখুন..." className="mt-1 w-full text-sm border p-3 rounded-xl"/></label>}
        <p className="text-xs text-amber-700 bg-amber-50 rounded-lg p-3">{selected.platform==='whatsapp'?'Only contacts with recorded marketing opt-in are eligible. Template must be approved by Meta.':isMeta?'Facebook/Instagram campaigns are restricted to contacts with an inbound interaction within the last 24 hours.':'Telegram campaigns target active subscribers; follow applicable consent and platform rules.'}</p>
        <button type="submit" disabled={sending||!channelId} className="w-full py-3 bg-blue-600 text-white text-sm font-semibold rounded-xl disabled:opacity-50">{sending?'Queueing…':'Queue broadcast'}</button>
      </form>}
    </div>
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-4 border-b flex items-center justify-between"><h3 className="text-sm font-semibold">Campaign history ({campaigns.length})</h3><button onClick={()=>reload(channelId)} disabled={!channelId||loading} className="text-xs border rounded-lg px-3 py-2">{loading?'Loading…':'Refresh'}</button></div>
      {!channelId?<p className="p-8 text-sm text-center text-slate-500">Select a channel to view campaign history.</p>:campaigns.length===0?<p className="p-8 text-sm text-center text-slate-500">No campaigns yet.</p>:
      <div className="divide-y">{campaigns.map(c=><div key={c.id} className="p-4 flex flex-col sm:flex-row sm:justify-between gap-3"><div><p className="font-semibold text-sm">{c.name||'Broadcast'}</p><p className="text-sm text-slate-600 mt-1 whitespace-pre-wrap">{c.template_name?`WhatsApp template: ${c.template_name} (${c.template_language})`:c.message_text}</p><p className="text-xs text-slate-400 mt-2">{c.created_at?new Date(c.created_at).toLocaleString():''}</p></div><div className="text-xs min-w-28"><p className="font-semibold">{c.status}</p><p className="text-emerald-700 mt-1">Sent: {c.sent_count||0}</p><p className="text-red-600">Failed: {c.failed_count||0}</p></div></div>)}</div>}
    </div>
  </div>;
}
